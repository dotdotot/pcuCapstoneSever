from fastapi import FastAPI
from requests import Session
from fastapi.params import Depends
from typing import List
from starlette.responses import RedirectResponse
from pydantic import BaseModel
import models, schemas
import uvicorn
from db import SessionLocal, enigne

models.Base.metadata.create_all(bind=enigne)

app = FastAPI()

def get_db():
    try:
        db = SessionLocal()
        yield db
    finally:
        db.close()

@app.get("/")
def main():
    return RedirectResponse(url="/docs/")

#전체 유저 출력
@app.get('/user/', response_model=List[schemas.User])
def show_users(db: Session=Depends(get_db)):
    user = db.query(models.User).all( )
    return user

#유저 생성
@app.post('/user/', response_model=schemas.User)
def create_users(entrada: schemas.User, db: Session=Depends(get_db)):
    user = models.User(id = entrada.id, name = entrada.name)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user

#id에 해당하는 유저 출력
@app.get('/user/{user_id}', response_model=schemas.User)
def read_users(user_id:int,db: Session=Depends(get_db)):
    user = db.query(models.User).filter_by(id=user_id).first()
    return user


if __name__  == '__main__':
    uvicorn.run(app="main:app", 
                host="203.250.133.171",
                port=8000,
                reload=True,) 
 